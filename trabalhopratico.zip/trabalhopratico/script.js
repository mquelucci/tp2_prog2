const music = new Audio('musica.mp3');

function musicadefundo(){
    document.getElementById("audio").play();
}

function login(){
    alert("Login efetuado com sucesso!");
}

function impressao(){
    alert("Impressão iniciada!");
}

function off(){
    alert("ATENÇÃO!!! Você está offline!")
}

